function sayHello() {
  alert("Hello from AWS S3 + CloudFront!");
}
